package com.project.service.Rating.Exceptions;

public class NoRatingFoundException {

}
